// Script to update the 'url' column in the 'sounds' table based on matching
// the 'name' column with filenames found in the root of the 'audio' bucket.

// Adjust import for CommonJS/ESM compatibility
import supabaseJs from '@supabase/supabase-js';
const { createClient } = supabaseJs;
type SupabaseClient = supabaseJs.SupabaseClient; // Get type via namespace

import path from 'path';

// --- Configuration ---
const supabaseUrl = "https://rnmmonnvfrqhfcunpyvt.supabase.co";
// Make sure this is your SERVICE ROLE KEY
const supabaseServiceKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJubW1vbm52ZnJxaGZjdW5weXZ0Iiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc0NDU2Nzc4NSwiZXhwIjoyMDYwMTQzNzg1fQ.hPcTu9i-dyjp8nh1t-nrT6vb2LMz3W1UE0bIWwqH4k4";

const BUCKET_NAME = 'audio';
const MAX_FILES_PER_LIST = 1000; // Storage list limit per call
const DB_FETCH_CHUNK_SIZE = 500; // How many sounds to fetch from DB at once
const DB_UPDATE_BATCH_SIZE = 100; // How many sounds to update in DB at once
// --- End Configuration ---

if (!supabaseServiceKey || supabaseServiceKey.includes("YOUR_SUPABASE")) {
    throw new Error("Supabase Service Role Key is not set correctly in scripts/updateSoundUrlsFromStorage.ts.");
}

const supabase: SupabaseClient = createClient(supabaseUrl, supabaseServiceKey);

interface DbSoundPartial {
    id: string;
    name: string | null; // Name might be nullable
    url: string | null; // Current URL
}

interface FileUpdate {
    id: string;
    url: string; // The new URL (filename)
}

interface UnmatchedSound {
    id: string;
    dbName: string | null;
}

// Function to list all files in the root of the bucket
async function listAllFiles(): Promise<Set<string>> {
    const allFiles = new Set<string>();
    let offset = 0;
    let hasMore = true;

    console.log(`Listing files in bucket root: ${BUCKET_NAME}`);

    while (hasMore) {
        const { data, error } = await supabase.storage
            .from(BUCKET_NAME)
            .list('', { // List root directory
                limit: MAX_FILES_PER_LIST,
                offset: offset,
            });

        if (error) {
            console.error(`Error listing files in ${BUCKET_NAME} at offset ${offset}:`, error);
            throw error;
        }

        if (data && data.length > 0) {
            const filesOnly = data.filter(f => f.id !== null && f.name !== '.emptyFolderPlaceholder');
            filesOnly.forEach(f => allFiles.add(f.name)); // Add original filename
            offset += data.length;
            hasMore = data.length === MAX_FILES_PER_LIST;
            console.log(`  Listed ${filesOnly.length} items (total unique: ${allFiles.size}, offset ${offset}). More: ${hasMore}`);
        } else {
            hasMore = false;
             console.log(`  No more items found (offset ${offset}).`);
        }
    }
    console.log(`Total unique filenames found in bucket root: ${allFiles.size}`);
    return allFiles; // Return Set<original filename>
}

// Normalize filename/path for comparison (lowercase, trim whitespace, remove specific chars)
function normalizeName(name: string | null | undefined): string {
    if (!name) return '';
    return name
        .trim()
        .toLowerCase()
        // Remove specific characters known to cause issues: #, (), []
        .replace(/[#()\[\]]/g, '')
         // Optional: Replace multiple spaces/underscores with a single one if needed
        // .replace(/[\s_]+/g, ' ');
}

// List of common audio extensions to try
const COMMON_AUDIO_EXTENSIONS = ['.wav', '.mp3', '.aiff', '.ogg', '.flac']; // Keep this? Maybe less relevant with full path matching

// Function to fetch sounds from DB in chunks
async function fetchSoundsFromDb(lastId: string | null = null): Promise<DbSoundPartial[]> {
    let query = supabase
        .from('sounds')
        .select('id, name, url')
        .limit(DB_FETCH_CHUNK_SIZE)
        .order('id'); // Consistent ordering for pagination

    if (lastId) {
        query = query.gt('id', lastId); // Get sounds after the last fetched ID
    }

    const { data, error } = await query;

    if (error) {
        console.error('Error fetching sounds from database:', error);
        throw error;
    }
    return data || [];
}

// Function to update DB in batches (Now individual updates)
async function updateDatabaseIndividually(updates: FileUpdate[]): Promise<void> {
    if (updates.length === 0) return;

    console.log(`Updating ${updates.length} records individually in database...`);

    // Use Promise.allSettled to run updates concurrently and handle individual errors
    const results = await Promise.allSettled(
        updates.map(update => {
            return supabase
                .from('sounds')
                .update({ url: update.url }) // Update only the url column
                .eq('id', update.id);
        })
    );

    results.forEach((result, index) => {
        if (result.status === 'rejected') {
            // Supabase client errors usually have a nested error object
            const errorDetails = result.reason?.error || result.reason;
            console.error(`  Error updating sound ID ${updates[index].id}:`, errorDetails);
        } else if (result.status === 'fulfilled') {
            // Supabase returns { data, error } on success/failure
            if (result.value.error) {
                 console.error(`  Error updating sound ID ${updates[index].id}:`, result.value.error);
            }
        }
    });

    console.log(`  Finished attempting individual updates for ${updates.length} records.`);

}

// Main sync function
async function syncUrls() {
    console.log("--- Starting URL Sync Process ---");
    // Set of original filenames found in the root
    let storageFilesRaw: Set<string>;
    try {
        // Use the non-recursive function again
        storageFilesRaw = await listAllFiles();
        if (storageFilesRaw.size === 0) {
            console.error("No files found in storage bucket root. Aborting sync.");
            return;
        }
    } catch (e) {
        console.error("Failed to list storage files from root. Aborting sync.", e);
        return;
    }

    // Create a map for efficient lookup: normalized filename -> original filename
    const storageFilesNormalizedMap = new Map<string, string>();
    storageFilesRaw.forEach(filename => {
        // Only store root files. Key is normalized name, value is original name.
        storageFilesNormalizedMap.set(normalizeName(filename), filename);
    });
    console.log(`Normalized ${storageFilesNormalizedMap.size} storage filenames from root for matching.`);


    let lastId: string | null = null;
    let dbSoundsFetched = 0;
    let updatesToPerform: FileUpdate[] = [];
    let totalUpdatesNeeded = 0;
    let totalSoundsProcessed = 0;
    let totalMatchesFound = 0;
    let totalNoName = 0;
    let totalNoMatch = 0;
    let keepFetching = true;
    const unmatchedSounds: UnmatchedSound[] = [];

    console.log("\nFetching sounds from database...");

    while (keepFetching) {
        const soundsChunk = await fetchSoundsFromDb(lastId);
        dbSoundsFetched = soundsChunk.length;
        totalSoundsProcessed += dbSoundsFetched;

        if (dbSoundsFetched === 0) {
            keepFetching = false;
            console.log("Finished fetching all sounds from database.");
            break;
        }

        console.log(`  Processing chunk of ${dbSoundsFetched} sounds (starting after ID: ${lastId})...`);
        lastId = soundsChunk[dbSoundsFetched - 1].id; // Prepare for next fetch

        for (const sound of soundsChunk) {
            if (!sound.name) {
                console.warn(`  - Sound ID ${sound.id} has NULL name. Skipping.`);
                totalNoName++;
                continue;
            }

            // Normalize the DATABASE name using the enhanced function
            const dbNameNormalized = normalizeName(sound.name);
            let matchedFilenameOriginal: string | null = null; // Store the original case filename from root

            // Strategy: Match normalized DB name against normalized root filenames
            if (storageFilesNormalizedMap.has(dbNameNormalized)) {
                matchedFilenameOriginal = storageFilesNormalizedMap.get(dbNameNormalized)!;
            }
            // Try adding common extensions if db name seems extensionless
            else if (!dbNameNormalized.includes('.')) {
                for (const ext of COMMON_AUDIO_EXTENSIONS) {
                    const nameWithExt = dbNameNormalized + ext;
                    if (storageFilesNormalizedMap.has(nameWithExt)) {
                        matchedFilenameOriginal = storageFilesNormalizedMap.get(nameWithExt)!;
                        // console.log(`    - Matched ID ${sound.id} ('${sound.name}') with extension ${ext} -> '${matchedFilenameOriginal}'`);
                        break; // Found a match with an extension
                    }
                }
            }

            if (matchedFilenameOriginal) {
                totalMatchesFound++;
                // Check if update is needed: current URL must be EXACTLY the root filename
                if (sound.url !== matchedFilenameOriginal) {
                    // Update needed (URL is NULL, has audio/ prefix, or is otherwise wrong)
                    updatesToPerform.push({ id: sound.id, url: matchedFilenameOriginal });
                    totalUpdatesNeeded++;
                     // console.log(`    - Update needed for ID ${sound.id} ('${sound.url || 'NULL'}' -> '${matchedFilenameOriginal}')`);
                } else {
                     // console.log(`    - URL already correct for ID ${sound.id} ('${sound.url}')`);
                 }
            } else {
                // No match found in the root directory based on DB name
                // console.warn(`  - No match found in root for sound ID ${sound.id} (DB name: '${sound.name}')`);
                unmatchedSounds.push({ id: sound.id, dbName: sound.name }); // Store details
                totalNoMatch++;
            }

            // Update DB individually
            if (updatesToPerform.length >= DB_UPDATE_BATCH_SIZE) {
                await updateDatabaseIndividually(updatesToPerform);
                updatesToPerform = []; // Reset batch
            }
        } // End loop for chunk

         console.log(`  Finished processing chunk. Total processed: ${totalSoundsProcessed}`);

    } // End while fetching

    // Update any remaining records
    await updateDatabaseIndividually(updatesToPerform);

    console.log("\n--- URL Sync Process Finished ---");
    console.log(`Total sounds processed from DB: ${totalSoundsProcessed}`);
    console.log(`Sounds skipped (NULL name): ${totalNoName}`);
    console.log(`Sounds with name match in storage root: ${totalMatchesFound}`);
    console.log(`Sounds with NO match in storage root: ${totalNoMatch}`);
    console.log(`Total URL updates performed (to fix prefix/NULL/etc.): ${totalUpdatesNeeded}`);

    // Log unmatched sounds if any
    if (unmatchedSounds.length > 0) {
        console.log(`\n--- Unmatched Sounds (${unmatchedSounds.length}) ---`);
        console.log("List format: Sound ID - Database Name"); // Removed ambiguous reason
        unmatchedSounds.forEach(unmatched => {
            console.log(`  ${unmatched.id} - '${unmatched.dbName}'`);
        });
        console.log("--- End of Unmatched Sounds ---");
    }

    console.log("\nPlease verify the 'url' column in the 'sounds' table.");
}

// Execute
syncUrls().catch(err => {
    console.error("\nAn unexpected error occurred during the URL sync script execution:", err);
}); 