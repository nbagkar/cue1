// Script to flatten the directory structure within the 'audio' bucket.
// Moves files from specified subfolders to the root of the bucket.

// Adjust import for CommonJS/ESM compatibility
import supabaseJs from '@supabase/supabase-js';
const { createClient } = supabaseJs;
type SupabaseClient = supabaseJs.SupabaseClient; // Get type via namespace

// Use default import for path in ES module context
import path from 'path';

// --- Configuration ---
const supabaseUrl = "https://rnmmonnvfrqhfcunpyvt.supabase.co";
// Make sure this is your SERVICE ROLE KEY
const supabaseServiceKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJubW1vbm52ZnJxaGZjdW5weXZ0Iiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc0NDU2Nzc4NSwiZXhwIjoyMDYwMTQzNzg1fQ.hPcTu9i-dyjp8nh1t-nrT6vb2LMz3W1UE0bIWwqH4k4";

const BUCKET_NAME = 'audio';
// List of *full paths* to the folders within the bucket whose contents you want to move to the root
const SOURCE_FOLDERS = [
    'audio' // Targeting the top-level 'audio' folder
    // 'audio/audio2', // Commented out
    // 'audio/sounds' // Commented out
];
const MAX_FILES_PER_LIST = 1000; // Adjust if you expect more files in a single folder
// --- End Configuration ---

if (!supabaseServiceKey || supabaseServiceKey.includes("YOUR_SUPABASE")) {
    throw new Error("Supabase Service Role Key is not set correctly in scripts/flattenAudioBucket.ts.");
}

const supabase: SupabaseClient = createClient(supabaseUrl, supabaseServiceKey);

interface FileErrorInfo {
    file: string;
    error: any;
}

// Function to generate a conflict-avoiding filename
function generateConflictName(originalPath: string, sourceFolder: string): string {
    const baseName = path.basename(originalPath, path.extname(originalPath));
    const extension = path.extname(originalPath);
    // Sanitize folder path to use in filename
    const folderSuffix = sourceFolder.replace(/\//g, '_'); // Replace slashes with underscores
    return `${baseName}_from_${folderSuffix}${extension}`;
}

// Function to list all files in a specific folder path within the bucket
async function listAllFiles(folderPath: string): Promise<{ name: string }[]> {
    let allFiles: { name: string }[] = [];
    let offset = 0;
    let hasMore = true;

    console.log(`Listing files in: ${BUCKET_NAME}/${folderPath}`);

    while (hasMore) {
        const { data, error } = await supabase.storage
            .from(BUCKET_NAME)
            .list(folderPath, {
                limit: MAX_FILES_PER_LIST,
                offset: offset,
                // sortBy: { column: 'name', order: 'asc' }, // Optional sorting
            });

        if (error) {
            console.error(`Error listing files in ${folderPath} at offset ${offset}:`, error);
            throw error; // Stop processing this folder on error
        }

        if (data && data.length > 0) {
            // Filter out potential placeholder files if necessary, though moving them shouldn't hurt
             const filesOnly = data.filter(f => f.name !== '.emptyFolderPlaceholder' && f.id !== null); // Check id is not null for actual files
             allFiles = allFiles.concat(filesOnly);
            offset += data.length;
            hasMore = data.length === MAX_FILES_PER_LIST; // Check if there might be more files
            console.log(`  Listed ${filesOnly.length} items (offset ${offset}). More: ${hasMore}`);
        } else {
            hasMore = false; // No more files found
             console.log(`  No more items found (offset ${offset}).`);
        }
    }
    console.log(`Total actual files listed in ${folderPath}: ${allFiles.length}`);
    return allFiles;
}


// Main function to process folders and move files
async function flattenBucketStructure() {
    console.log(`--- Starting Bucket Flattening Process for bucket: ${BUCKET_NAME} ---`);
    const totalErrors: FileErrorInfo[] = [];
    let totalMoved = 0;

    for (const folder of SOURCE_FOLDERS) {
        console.log(`
Processing source folder: ${folder}`);
        let filesToMove: { name: string }[] = [];
        try {
            filesToMove = await listAllFiles(folder);
        } catch (listError) {
            console.error(`Skipping folder ${folder} due to listing error.`);
            totalErrors.push({ file: `Folder: ${folder}`, error: 'Listing failed' });
            continue; // Move to the next folder
        }

        if (filesToMove.length === 0) {
            console.log(`No files found to move in ${folder}.`);
            continue;
        }

        for (const file of filesToMove) {
            const sourcePath = `${folder}/${file.name}`; // Full path in bucket
            let destinationPath = file.name; // Target: root of the bucket

            console.log(`  Preparing to move: ${sourcePath} -> ${destinationPath}`);

            try {
                 // Check for conflict at the destination (root)
                 const { data: existingFiles, error: checkError } = await supabase.storage
                    .from(BUCKET_NAME)
                    .list('', { search: destinationPath, limit: 1 }); // Search root for exact name

                 if (checkError) {
                     console.warn(`    WARN: Could not check for existing file at root for ${destinationPath}: ${checkError.message}. Attempting move anyway.`);
                 } else if (existingFiles && existingFiles.length > 0 && existingFiles[0].name === destinationPath) {
                     // Conflict detected!
                     const oldDestination = destinationPath;
                     destinationPath = generateConflictName(file.name, folder);
                     console.warn(`    WARN: Conflict detected for ${oldDestination}. Renaming to: ${destinationPath}`);
                 }

                // Move the file
                const { error: moveError } = await supabase.storage
                    .from(BUCKET_NAME)
                    .move(sourcePath, destinationPath); // Move within the same bucket

                if (moveError) {
                    console.error(`    ERROR moving ${sourcePath} to ${destinationPath}:`, moveError);
                    totalErrors.push({ file: sourcePath, error: moveError });
                } else {
                    console.log(`    Successfully moved ${sourcePath} to ${destinationPath}`);
                    totalMoved++;
                }
            } catch (moveException) {
                 console.error(`    EXCEPTION during move/check for ${sourcePath}:`, moveException);
                 totalErrors.push({ file: sourcePath, error: moveException });
            }
        } // End loop for files in folder
    } // End loop for folders

    console.log(`\n--- Bucket Flattening Process Finished ---`);
    console.log(`Total files successfully moved: ${totalMoved}`);
    if (totalErrors.length > 0) {
        console.warn(`Total errors encountered: ${totalErrors.length}`);
        totalErrors.forEach(err => console.warn(`  - File/Folder: ${err.file}, Error: ${err.error.message || err.error}`));
    } else {
        console.log(`All targeted files processed without errors.`);
    }
    console.log(`\nPlease verify the files in the root of the 'audio' bucket.`);
    console.log(`You may need to manually delete the original (now potentially empty) source folders via the Supabase dashboard.`);
}

// Execute the main function
flattenBucketStructure().catch(err => {
    console.error(`\nAn unexpected error occurred during the script execution:`, err);
}); 