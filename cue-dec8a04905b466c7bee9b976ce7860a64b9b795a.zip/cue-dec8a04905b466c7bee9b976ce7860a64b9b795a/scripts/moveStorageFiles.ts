// Script to move files from one Supabase Storage bucket to another

import { createClient } from '@supabase/supabase-js';

// Use the actual credentials from your project
const supabaseUrl = "https://rnmmonnvfrqhfcunpyvt.supabase.co";
const supabaseAnonKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJubW1vbm52ZnJxaGZjdW5weXZ0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDQ1Njc3ODUsImV4cCI6MjA2MDE0Mzc4NX0.YB18Oogxf6z3YUzUZ77ORHdHRVm85Ots-pY8Ltz2Q5Q";

// Ensure you have the correct service_role key if anon key doesn't have sufficient permissions for listing/copying/deleting
const supabaseServiceKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJubW1vbm52ZnJxaGZjdW5weXZ0Iiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc0NDU2Nzc4NSwiZXhwIjoyMDYwMTQzNzg1fQ.hPcTu9i-dyjp8nh1t-nrT6vb2LMz3W1UE0bIWwqH4k4"; // <-- PASTE YOUR SERVICE ROLE KEY HERE

// Use service_role key for elevated permissions needed for script operations
if (!supabaseServiceKey) {
    throw new Error("Supabase Service Role Key is missing in scripts/moveStorageFiles.ts.");
}
const supabase = createClient(supabaseUrl, supabaseServiceKey);

const sourceBucket = 'sounds';
const destinationBucket = 'audio';

async function moveFiles() {
  console.log(`Listing files in bucket: ${sourceBucket}`);
  // Listing might require different permissions depending on bucket/RLS settings
  const { data: files, error: listError } = await supabase.storage
    .from(sourceBucket)
    .list('', { limit: 1000 }); // List files in the root, increase limit if needed

  if (listError) {
    console.error('Error listing files:', listError);
    console.error('Please ensure the bucket exists and the key used has list permissions.');
    return;
  }

  if (!files || files.length === 0) {
    console.log(`No files found in bucket: ${sourceBucket}`);
    return;
  }

  // Filter out placeholder files often created by Supabase UI
  const actualFiles = files.filter(file => file.name !== '.emptyFolderPlaceholder');

  if (actualFiles.length === 0) {
      console.log(`No actual files (excluding placeholders) found in bucket: ${sourceBucket}`);
      return;
  }

  console.log(`Found ${actualFiles.length} actual files to copy.`);

  const errors: { path: string, error: any }[] = [];

  for (const file of actualFiles) {
    const sourcePath = file.name;
    // Place files directly into the root of the destination bucket.
    // Change this if you want them in a subfolder e.g., `moved_from_sound/${file.name}`
    const destinationPath = file.name;

    console.log(`Attempting to copy: ${sourceBucket}/${sourcePath} -> ${destinationBucket}/${destinationPath}...`);

    // Correct way to copy across buckets using supabase-js v2
    const { data: copyData, error: copyError } = await supabase.storage
      .from(sourceBucket) // Specify the source bucket
      .copy(sourcePath, destinationPath, { // Specify source path, destination path relative to dest bucket
          destinationBucket: destinationBucket // Specify the destination bucket
      });

    if (copyError) {
      console.error(`ERROR copying file ${sourcePath}:`, copyError);
      errors.push({ path: sourcePath, error: copyError });
      // Continue processing other files even if one fails
    } else {
      console.log(`  Successfully copied ${sourcePath} to ${destinationPath} in bucket ${destinationBucket}`);
      // IMPORTANT: Deletion should only happen AFTER you verify the copy
      // AND after updating the database entries.
      // Consider deleting manually or in a separate step.
      // Uncomment to delete immediately after successful copy (use with caution!):
      /*
      console.log(`  Attempting to delete original: ${sourceBucket}/${sourcePath}...`);
      const { error: deleteError } = await supabase.storage.from(sourceBucket).remove([sourcePath]);
      if (deleteError) {
          console.error(`  ERROR deleting original file ${sourcePath}:`, deleteError);
          errors.push({ path: sourcePath, error: deleteError }); // Log deletion error too
      } else {
          console.log(`    Successfully deleted original ${sourcePath}`);
      }
      */
    }
  }

  console.log('--- File Copying Process Finished ---');
  if (errors.length > 0) {
      console.warn(`${errors.length} error(s) occurred during the process:`);
      errors.forEach(err => console.warn(`  - File: ${err.path}, Error: ${err.error.message || err.error}`));
  } else {
      console.log('All files processed successfully (check logs for details).');
  }
  console.log('Please verify the files in the destination bucket and update your database accordingly.');
}

// Execute the function
moveFiles().catch(err => {
  console.error("An unexpected error occurred during the script execution:", err);
}); 