import type { Sound } from "@/types/sound"

// Generate random waveform data for visualization
const generateWaveform = (length = 50): number[] => {
  return Array.from({ length }, () => Math.random() * 0.8 + 0.2)
}

export const mockSounds: Sound[] = [
  {
    id: "1",
    name: "Smooth Jazz Piano",
    bpm: 85,
    key: "C maj",
    duration: 124, // in seconds
    audioUrl: "/sounds/smooth-jazz-piano.mp3",
    waveform: generateWaveform(),
  },
  {
    id: "2",
    name: "Ambient Rain Forest",
    bpm: 60,
    key: "A min",
    duration: 187,
    audioUrl: "/sounds/ambient-rain-forest.mp3",
    waveform: generateWaveform(),
  },
  {
    id: "3",
    name: "Lo-fi Beats",
    bpm: 90,
    key: "D min",
    duration: 145,
    audioUrl: "/sounds/lo-fi-beats.mp3",
    waveform: generateWaveform(),
  },
  {
    id: "4",
    name: "Night City Ambience",
    bpm: 72,
    key: "G maj",
    duration: 210,
    audioUrl: "/sounds/night-city-ambience.mp3",
    waveform: generateWaveform(),
  },
  {
    id: "5",
    name: "Classical Strings",
    bpm: 110,
    key: "E min",
    duration: 168,
    audioUrl: "/sounds/classical-strings.mp3",
    waveform: generateWaveform(),
  },
]
