import type { Sound } from "@/types/sound"

// Generate random waveform data for visualization
const generateWaveform = (length = 50): number[] => {
  return Array.from({ length }, () => Math.random() * 0.8 + 0.2)
}

export const mockLibrary: Sound[] = [
  {
    id: "lib-1",
    name: "Midnight Jazz Session",
    bpm: 92,
    key: "D min",
    duration: 178, // in seconds
    audioUrl: "/sounds/midnight-jazz.mp3",
    waveform: generateWaveform(),
    isSaved: true,
  },
  {
    id: "lib-2",
    name: "Urban Cityscape Ambience",
    bpm: 70,
    key: "G maj",
    duration: 210,
    audioUrl: "/sounds/urban-cityscape.mp3",
    waveform: generateWaveform(),
    isSaved: true,
  },
  {
    id: "lib-3",
    name: "Rainy Day Piano",
    bpm: 85,
    key: "C maj",
    duration: 145,
    audioUrl: "/sounds/rainy-day-piano.mp3",
    waveform: generateWaveform(),
    isSaved: true,
  },
  {
    id: "lib-4",
    name: "Lofi Study Beats",
    bpm: 90,
    key: "A min",
    duration: 163,
    audioUrl: "/sounds/lofi-study-beats.mp3",
    waveform: generateWaveform(),
    isSaved: true,
  },
  {
    id: "lib-5",
    name: "Acoustic Guitar Melodies",
    bpm: 110,
    key: "E min",
    duration: 192,
    audioUrl: "/sounds/acoustic-guitar.mp3",
    waveform: generateWaveform(),
    isSaved: true,
  },
  {
    id: "lib-6",
    name: "Synth Wave Retro",
    bpm: 120,
    key: "F maj",
    duration: 185,
    audioUrl: "/sounds/synth-wave.mp3",
    waveform: generateWaveform(),
    isSaved: true,
  },
]
