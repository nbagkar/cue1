import type { SavedSearch } from "@/types/search"

// Helper to create dates for different periods
const createDate = (daysAgo: number): Date => {
  const date = new Date()
  date.setDate(date.getDate() - daysAgo)
  return date
}

export const mockSavedSearches: SavedSearch[] = [
  {
    id: "1",
    query: "Jazz piano with rain",
    createdAt: createDate(0), // Today
  },
  {
    id: "2",
    query: "Summer beach waves",
    createdAt: createDate(0), // Today
  },
  {
    id: "3",
    query: "Night city ambience",
    createdAt: createDate(1), // Yesterday
  },
  {
    id: "4",
    query: "Lofi beats for studying",
    createdAt: createDate(2), // Past 3 days
  },
  {
    id: "5",
    query: "Ambient forest sounds",
    createdAt: createDate(3), // Past 3 days
  },
  {
    id: "6",
    query: "Thunderstorm with piano",
    createdAt: createDate(4), // Past 7 days
  },
  {
    id: "7",
    query: "Classical music compilation",
    createdAt: createDate(5), // Past 7 days
  },
  {
    id: "8",
    query: "Coffee shop background noise",
    createdAt: createDate(6), // Past 7 days
  },
]
