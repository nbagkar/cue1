-- Migration to populate sound_tags table from existing tags column

-- First, create a function to split tags and create Tag entries if they don't exist
CREATE OR REPLACE FUNCTION public.populate_sound_tags()
RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
  sound_record RECORD;
  tag_name TEXT;
  tag_id UUID;
  tag_names TEXT[];
BEGIN
  -- Loop through all sounds
  FOR sound_record IN SELECT id, tags FROM public.sounds WHERE tags IS NOT NULL AND tags != ''
  LOOP
    -- Split tags by comma and trim whitespace
    tag_names := string_to_array(trim(sound_record.tags), ',');
    
    -- Process each tag
    FOREACH tag_name IN ARRAY tag_names
    LOOP
      tag_name := trim(tag_name);
      
      -- Skip empty tags
      IF tag_name = '' THEN
        CONTINUE;
      END IF;
      
      -- Check if tag exists
      SELECT id INTO tag_id FROM public."Tag" WHERE name = tag_name;
      
      -- If tag doesn't exist, create it
      IF tag_id IS NULL THEN
        tag_id := gen_random_uuid();
        INSERT INTO public."Tag" (id, name, "updatedAt")
        VALUES (tag_id, tag_name, NOW());
      END IF;
      
      -- Create sound-tag relationship if it doesn't exist
      INSERT INTO public.sound_tags (sound_id, tag_id)
      VALUES (sound_record.id, tag_id)
      ON CONFLICT (sound_id, tag_id) DO NOTHING;
    END LOOP;
  END LOOP;
END;
$$;

-- Run the function
SELECT public.populate_sound_tags();

-- Drop the function after use
DROP FUNCTION public.populate_sound_tags(); 