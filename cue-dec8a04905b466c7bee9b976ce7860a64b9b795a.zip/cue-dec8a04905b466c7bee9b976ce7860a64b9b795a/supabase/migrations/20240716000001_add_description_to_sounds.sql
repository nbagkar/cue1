-- Add description column to sounds table
ALTER TABLE public.sounds
ADD COLUMN IF NOT EXISTS description text;

-- Update the type definition for sounds table
COMMENT ON COLUMN public.sounds.description IS 'Description of the sound'; 