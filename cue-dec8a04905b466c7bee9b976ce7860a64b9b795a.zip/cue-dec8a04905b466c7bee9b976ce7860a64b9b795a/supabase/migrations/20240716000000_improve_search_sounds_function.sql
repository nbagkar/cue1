-- Improved version of search_sounds_by_tags function with partial matching and logging

-- Drop the old function
DROP FUNCTION IF EXISTS public.search_sounds_by_tags(text[]);

-- Create a new improved version
CREATE OR REPLACE FUNCTION public.search_sounds_by_tags(search_keywords text[])
RETURNS SETOF sounds
LANGUAGE plpgsql
STABLE
AS $$
DECLARE
  match_count integer := 0;
  log_message text;
  word text;
  words text[];
BEGIN
  -- Log the search keywords for debugging
  log_message := 'Searching with keywords: ' || array_to_string(search_keywords, ', ');
  RAISE NOTICE '%', log_message;
  
  -- Split each keyword into words and create a flattened array of all words
  words := ARRAY[]::text[];
  FOREACH word IN ARRAY search_keywords
  LOOP
    words := words || regexp_split_to_array(LOWER(word), '\s+');
  END LOOP;
  
  -- Remove duplicates and empty strings
  words := ARRAY(SELECT DISTINCT unnest(words) WHERE unnest != '');
  
  RAISE NOTICE 'Searching with individual words: %', array_to_string(words, ', ');
  
  -- First check how many tags actually exist in our database
  SELECT COUNT(*) INTO match_count
  FROM "Tag" t
  WHERE LOWER(t.name) IN (SELECT LOWER(kw) FROM unnest(words) as kw);
  
  RAISE NOTICE 'Found % exact matching tags in database', match_count;
  
  -- If we have exact matches, use those first
  IF match_count > 0 THEN
    RETURN QUERY
    SELECT DISTINCT s.*
    FROM public.sounds s
    JOIN public.sound_tags st ON s.id = st.sound_id
    JOIN public."Tag" t ON st.tag_id = t.id
    WHERE LOWER(t.name) IN (SELECT LOWER(kw) FROM unnest(words) as kw)
    ORDER BY 
      -- Prioritize sounds that match more words
      (SELECT COUNT(*) FROM unnest(words) w WHERE LOWER(t.name) = LOWER(w)) DESC,
      s.name ASC;
  
  -- If no exact matches, try partial matches with LIKE
  ELSE
    RAISE NOTICE 'No exact matches, trying partial matches';
    RETURN QUERY
    SELECT DISTINCT s.*
    FROM public.sounds s
    JOIN public.sound_tags st ON s.id = st.sound_id
    JOIN public."Tag" t ON st.tag_id = t.id
    WHERE 
      EXISTS (
        SELECT 1 FROM unnest(words) as kw
        WHERE LOWER(t.name) LIKE '%' || LOWER(kw) || '%'
      )
    ORDER BY 
      -- Prioritize sounds that match more words
      (SELECT COUNT(*) FROM unnest(words) w WHERE LOWER(t.name) LIKE '%' || LOWER(w) || '%') DESC,
      s.name ASC;
  END IF;
  
  -- If still no results, try searching in the sound name and description
  IF NOT FOUND THEN
    RAISE NOTICE 'No tag matches found, trying sound name and description';
    RETURN QUERY
    SELECT DISTINCT s.*
    FROM public.sounds s
    WHERE 
      EXISTS (
        SELECT 1 FROM unnest(words) as kw
        WHERE 
          LOWER(s.name) LIKE '%' || LOWER(kw) || '%' OR
          (s.description IS NOT NULL AND LOWER(s.description) LIKE '%' || LOWER(kw) || '%')
      )
    ORDER BY 
      -- Prioritize sounds that match more words
      (SELECT COUNT(*) FROM unnest(words) w 
        WHERE LOWER(s.name) LIKE '%' || LOWER(w) || '%' OR
        (s.description IS NOT NULL AND LOWER(s.description) LIKE '%' || LOWER(w) || '%')
      ) DESC,
      s.name ASC;
  END IF;
  
  -- If still no results, return a subset of all sounds as a fallback
  IF NOT FOUND THEN
    RAISE NOTICE 'No matches found, returning fallback sounds';
    RETURN QUERY
    SELECT * FROM public.sounds
    ORDER BY RANDOM()
    LIMIT 10;
  END IF;
END;
$$;

-- Grant execute permission
GRANT EXECUTE ON FUNCTION public.search_sounds_by_tags(text[]) TO authenticated;

-- Create a helper function to list all available tags
CREATE OR REPLACE FUNCTION public.list_all_tags()
RETURNS TABLE(id text, name text, count bigint)
LANGUAGE sql
STABLE
AS $$
  SELECT 
    t.id::text, 
    t.name, 
    COUNT(st.sound_id) as sound_count
  FROM 
    public."Tag" t
  LEFT JOIN 
    public.sound_tags st ON t.id = st.tag_id
  GROUP BY 
    t.id, t.name
  ORDER BY 
    COUNT(st.sound_id) DESC, 
    t.name ASC;
$$;

GRANT EXECUTE ON FUNCTION public.list_all_tags() TO authenticated; 