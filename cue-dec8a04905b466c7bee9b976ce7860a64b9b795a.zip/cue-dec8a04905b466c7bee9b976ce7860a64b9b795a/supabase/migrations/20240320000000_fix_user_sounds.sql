-- Drop existing foreign key constraint
ALTER TABLE user_sounds DROP CONSTRAINT IF EXISTS user_sounds_library_id_fkey;

-- Drop existing columns
ALTER TABLE user_sounds DROP COLUMN IF EXISTS library_id;

-- Add user_id column and foreign key
ALTER TABLE user_sounds ADD COLUMN user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE;

-- Add RLS policies
ALTER TABLE user_sounds ENABLE ROW LEVEL SECURITY;

-- Drop any existing policies
DROP POLICY IF EXISTS "Users can view their own saved sounds" ON user_sounds;
DROP POLICY IF EXISTS "Users can save sounds" ON user_sounds;
DROP POLICY IF EXISTS "Users can remove saved sounds" ON user_sounds;

-- Create new policies
CREATE POLICY "Users can view their own saved sounds"
ON user_sounds FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Users can save sounds"
ON user_sounds FOR INSERT
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can remove saved sounds"
ON user_sounds FOR DELETE
USING (auth.uid() = user_id);

-- Add realtime
ALTER PUBLICATION supabase_realtime ADD TABLE user_sounds; 