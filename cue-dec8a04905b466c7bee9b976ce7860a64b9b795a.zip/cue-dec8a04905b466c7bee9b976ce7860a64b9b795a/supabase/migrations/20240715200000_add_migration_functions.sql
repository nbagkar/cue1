-- Create a function to migrate user_id values to profile_id
CREATE OR REPLACE FUNCTION migrate_user_id_to_profile_id()
RETURNS TEXT AS $$
DECLARE
  affected_rows INT;
  result TEXT;
BEGIN
  -- Check if both columns exist
  IF EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'user_sounds' 
    AND column_name = 'user_id'
  ) AND EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'user_sounds' 
    AND column_name = 'profile_id'
  ) THEN
    -- Update profile_id with user_id where profile_id is null and user_id isn't
    UPDATE user_sounds 
    SET profile_id = user_id 
    WHERE profile_id IS NULL AND user_id IS NOT NULL;
    
    GET DIAGNOSTICS affected_rows = ROW_COUNT;
    result := 'Migrated ' || affected_rows || ' records from user_id to profile_id';
  ELSE
    -- If columns don't exist as expected
    result := 'Schema does not match expected structure';
  END IF;
  
  RETURN result;
END;
$$ LANGUAGE plpgsql;

-- Create a function to get table column information
CREATE OR REPLACE FUNCTION get_column_info(table_name TEXT)
RETURNS JSON AS $$
BEGIN
  RETURN (
    SELECT json_agg(json_build_object(
      'column_name', column_name,
      'data_type', data_type,
      'is_nullable', is_nullable
    ))
    FROM information_schema.columns
    WHERE table_name = $1
  );
END;
$$ LANGUAGE plpgsql; 