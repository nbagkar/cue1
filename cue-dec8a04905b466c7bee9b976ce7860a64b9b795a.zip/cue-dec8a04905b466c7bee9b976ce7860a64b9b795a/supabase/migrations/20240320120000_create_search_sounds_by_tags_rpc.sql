-- Migration to create a function for searching sounds by tags

-- Drop the function if it exists to ensure a clean state on re-run
DROP FUNCTION IF EXISTS public.search_sounds_by_tags(text[]);

-- Create the function
CREATE OR REPLACE FUNCTION public.search_sounds_by_tags(search_keywords text[])
RETURNS SETOF sounds -- The function will return rows matching the 'sounds' table structure
LANGUAGE sql
STABLE -- Indicates the function doesn't modify the database
AS $$
  SELECT
      s.* -- Select all columns from the sounds table
  FROM
      public.sounds s
  JOIN
      public.sound_tags st ON s.id = st.sound_id -- Join sounds with the junction table
  JOIN
      public."Tag" t ON st.tag_id = t.id -- Join junction table with Tags (assuming table name is "Tag")
  WHERE
      -- Filter where the tag name (lowercase) is in the provided keyword list (lowercase)
      LOWER(t.name) IN (SELECT LOWER(kw) FROM unnest(search_keywords) as kw)
  GROUP BY
      s.id -- Group by sound ID to get distinct sounds
  ORDER BY
      -- Order by the count of distinct matching tags (more matches = higher rank)
      COUNT(DISTINCT LOWER(t.name)) DESC,
      -- Secondary sort by name for consistent ordering among sounds with the same score
      s.name ASC;
$$;

-- Grant execute permission on the function to the 'authenticated' role
-- This allows logged-in users to call this function via the API
GRANT EXECUTE ON FUNCTION public.search_sounds_by_tags(text[]) TO authenticated; 