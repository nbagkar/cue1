-- This migration handles existing user_sounds entries without profile_id values
-- It sets current user_sounds without a profile_id to NULL (effectively excluding them from queries)

-- First show existing entries with NULL profile_id
SELECT * FROM user_sounds WHERE profile_id IS NULL;

-- Clean up entries with NULL profile_id
-- Option 1: Delete all user_sounds without profile_id
-- DELETE FROM user_sounds WHERE profile_id IS NULL;

-- Option 2: If you want to retain existing entries for data continuity, 
-- you can alter the column to be NOT NULL with default value
-- This will make future queries more reliable
ALTER TABLE user_sounds 
  ALTER COLUMN profile_id SET NOT NULL; 