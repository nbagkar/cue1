import { supabase } from './supabase'
import type { Bucket, FileObject } from '@supabase/storage-js'

const BUCKET_NAME = 'sounds'
const MAX_FILE_SIZE = 50 * 1024 * 1024 // 50MB

// Initialize storage bucket
export async function initializeStorage() {
  try {
    // Check if bucket exists
    const { data: buckets } = await supabase.storage.listBuckets()
    const bucketExists = buckets?.some((bucket: Bucket) => bucket.name === BUCKET_NAME)

    if (!bucketExists) {
      // Create the bucket if it doesn't exist
      const { data, error } = await supabase.storage.createBucket(BUCKET_NAME, {
        public: false, // Files are not public by default
        fileSizeLimit: MAX_FILE_SIZE,
        allowedMimeTypes: ['audio/mpeg', 'audio/wav', 'audio/mp3', 'audio/x-wav']
      })

      if (error) {
        throw error
      }
    }

    return true
  } catch (error) {
    console.error('Error initializing storage:', error)
    return false
  }
}

// Function to get the correct audio path
function getAudioPath(path: string): string {
  // Remove any leading slashes and clean up the path
  return path.replace(/^\/+/, '').replace(/audio\//g, '');
}

// Upload a sound file
export async function uploadSound(file: File, userId: string): Promise<string | null> {
  try {
    // Validate file size
    if (file.size > MAX_FILE_SIZE) {
      throw new Error('File size exceeds 50MB limit')
    }

    // Create a unique file path
    const timestamp = Date.now()
    const fileExt = file.name.split('.').pop()
    const filePath = getAudioPath(`${userId}/${timestamp}.${fileExt}`)

    // Upload the file
    const { data, error } = await supabase.storage
      .from(BUCKET_NAME)
      .upload(filePath, file)

    if (error) {
      throw error
    }

    // Get the public URL
    const { data: { publicUrl } } = supabase.storage
      .from(BUCKET_NAME)
      .getPublicUrl(filePath)

    return publicUrl
  } catch (error) {
    console.error('Error uploading sound:', error)
    return null
  }
}

// Delete a sound file
export async function deleteSound(filePath: string): Promise<boolean> {
  try {
    // Ensure the path is correct
    const path = getAudioPath(filePath)
    
    const { error } = await supabase.storage
      .from(BUCKET_NAME)
      .remove([path])

    if (error) {
      throw error
    }

    return true
  } catch (error) {
    console.error('Error deleting sound:', error)
    return false
  }
}

// Get a temporary URL for a private file
export async function getSignedUrl(filePath: string): Promise<string | null> {
  try {
    // Ensure the path is correct
    const path = getAudioPath(filePath)
    
    const { data, error } = await supabase.storage
      .from(BUCKET_NAME)
      .createSignedUrl(path, 3600) // URL valid for 1 hour

    if (error) {
      throw error
    }

    return data.signedUrl
  } catch (error) {
    console.error('Error getting signed URL:', error)
    return null
  }
}

// List all audio files in a directory
export async function listAudioFiles(directory: string = ''): Promise<string[]> {
  try {
    const path = getAudioPath(directory)
    const { data, error } = await supabase.storage
      .from(BUCKET_NAME)
      .list(path, {
        limit: 100,
        offset: 0,
        sortBy: { column: 'name', order: 'asc' }
      })

    if (error) {
      throw error
    }

    return data.map((file: FileObject) => `${path}/${file.name}`)
  } catch (error) {
    console.error('Error listing audio files:', error)
    return []
  }
}

// Update the storage policies
export async function updateStoragePolicies() {
  try {
    // Enable RLS
    await supabase.rpc('set_storage_rls', { enable: true })

    // Create policy for authenticated users to upload files
    await supabase.rpc('create_storage_policy', {
      bucket: BUCKET_NAME,
      policy_name: 'authenticated can upload',
      definition: '(auth.role() = \'authenticated\')',
      operation: 'INSERT'
    })

    // Create policy for users to access their own files
    await supabase.rpc('create_storage_policy', {
      bucket: BUCKET_NAME,
      policy_name: 'users can access own files',
      definition: '(auth.uid() = owner_id)',
      operation: 'SELECT'
    })

    return true
  } catch (error) {
    console.error('Error updating storage policies:', error)
    return false
  }
} 