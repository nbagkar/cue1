import OpenAI from 'openai';
// Import the necessary type
import { ChatCompletionMessageParam } from 'openai/resources/chat/completions';

// Initialize OpenAI client with fallback for missing API key
const apiKey = process.env.OPENAI_API_KEY || 'sk-hardcoded-key-for-dev-only';

// For development/demo, initialize with a fallback to prevent crashes
const openai = new OpenAI({
  apiKey,
  // Warning: This is only safe in development/demo contexts
  dangerouslyAllowBrowser: true,
});

interface TagCategory {
  category: string;
  tags: string[];
}

/**
 * Convert a natural language search query into semantic search tags
 * @param query The natural language query to convert
 * @returns Array of semantic tags
 */
export async function getSemanticSearchQuery(query: string): Promise<string[]> {
  console.log(`[getSemanticSearchQuery] Converting query to keywords: "${query}"`);
  
  if (!query || query.trim() === '') {
    console.log('[getSemanticSearchQuery] Empty query, returning empty array');
    return [];
  }
  
  try {
    const response = await openai.chat.completions.create({
      model: 'gpt-4o',
      messages: [
        {
          role: 'system',
          content: `You are an audio search expert. Your job is to convert natural language audio search queries into relevant tags for a sound library.
          
The tags should follow these formats:
- instrument/source:[instrument or sound source]
- genre:[genre name]
- mood:[mood descriptor]
- style:[style descriptor]
- tempo:[tempo descriptor]
- key:[musical key]

Examples:
- "I need a relaxing piano piece" → ["instrument/source:piano", "mood:relaxing"]
- "Looking for upbeat electronic dance music" → ["genre:electronic", "genre:dance", "mood:upbeat"]
- "I want dark cinematic sounds for a horror scene" → ["genre:cinematic", "mood:dark", "style:horror"]
- "Give me some funk bass" → ["genre:funk", "instrument/source:bass"]
- "I need slow ambient music in C minor" → ["genre:ambient", "tempo:slow", "key:c minor"]

Return ONLY an array of these tags. Do not include any explanations or context. Aim for 2-5 tags maximum.`
        },
        {
          role: 'user',
          content: query
        }
      ],
      temperature: 0.7,
      max_tokens: 150,
    });

    // Extract the tags from the response
    const tagsText = response.choices[0]?.message?.content || '';
    console.log(`[getSemanticSearchQuery] Raw response: ${tagsText}`);
    
    // Parse the response - expecting a JSON array or array-like text
    let tags: string[] = [];
    
    try {
      // First try to parse as JSON
      tags = JSON.parse(tagsText);
    } catch (e) {
      // If JSON parsing fails, try to extract tags manually from text
      const matches = tagsText.match(/["']([^"']+)["']/g);
      if (matches) {
        tags = matches.map(match => match.replace(/^["']|["']$/g, ''));
      } else {
        // Last resort, split by commas and clean up
        tags = tagsText
          .replace(/[\[\]"']/g, '')
          .split(',')
          .map(tag => tag.trim())
          .filter(Boolean);
      }
    }
    
    // Filter out invalid tags or non-matching formats
    const validTags = tags.filter(tag => {
      return tag.match(/^(instrument\/source|genre|mood|style|tempo|key):.+/);
    });
    
    console.log(`[getSemanticSearchQuery] Generated valid tags: ${JSON.stringify(validTags)}`);
    return validTags;
  } catch (error) {
    console.error('[getSemanticSearchQuery] Error generating semantic tags:', error);
    
    // Fallback: Extract basic keywords from the query
    const fallbackTags = extractFallbackTags(query);
    console.log(`[getSemanticSearchQuery] Using fallback tags: ${JSON.stringify(fallbackTags)}`);
    return fallbackTags;
  }
}

/**
 * Extract basic fallback tags from a query when OpenAI is unavailable
 */
function extractFallbackTags(query: string): string[] {
  // Simple rule-based tag extraction for common instruments and genres
  const tagMappings = {
    'piano': 'instrument/source:piano',
    'guitar': 'instrument/source:guitar',
    'drums': 'instrument/source:drums',
    'bass': 'instrument/source:bass',
    'violin': 'instrument/source:violin',
    'synth': 'instrument/source:synth',
    'vocals': 'instrument/source:voice',
    'jazz': 'genre:jazz',
    'rock': 'genre:rock',
    'pop': 'genre:pop',
    'electronic': 'genre:electronic',
    'ambient': 'genre:ambient',
    'cinematic': 'genre:cinematic',
    'orchestral': 'genre:orchestral',
    'classical': 'genre:classical',
    'hip hop': 'genre:hip-hop',
    'happy': 'mood:happy',
    'sad': 'mood:sad',
    'dark': 'mood:dark',
    'relaxing': 'mood:relaxing',
    'upbeat': 'mood:upbeat',
    'slow': 'tempo:slow',
    'fast': 'tempo:fast',
    'medium': 'tempo:medium',
  };
  
  const lowerQuery = query.toLowerCase();
  const tags: string[] = [];
  
  // Check for each keyword in the query
  Object.entries(tagMappings).forEach(([keyword, tag]) => {
    if (lowerQuery.includes(keyword)) {
      tags.push(tag);
    }
  });
  
  // If no tags were found, add some default tags
  if (tags.length === 0) {
    return ['genre:ambient', 'mood:relaxing'];
  }
  
  return tags;
}

// Function to add fallback keywords based on user query
function addFallbackKeywords(query: string): string[] {
  console.log("[OpenAI] Adding fallback keywords for query:", query);
  
  // Default set of commonly-available tags
  const fallbacks = ['piano', 'strings', 'electronic', 'ambient', 'cinematic'];
  
  // Try to extract useful words directly from the query
  const queryWords = query.toLowerCase()
    .split(/\s+/)
    .filter(word => 
      word.length > 3 && 
      !['the', 'and', 'for', 'with', 'that', 'this', 'from', 'what', 'when', 'where', 'which'].includes(word)
    );
  
  // Combine query words with fallbacks, prioritizing query words
  const combined = [...new Set([...queryWords, ...fallbacks])];
  
  console.log("[OpenAI] Using fallback keywords:", combined.slice(0, 3));
  
  // Return at most 3 keywords to avoid too broad searches
  return combined.slice(0, 3);
}

// Function to normalize tags for comparison
export function normalizeTags(tags: string[] = []): string[] {
  if (!tags || !Array.isArray(tags)) {
    console.warn('[normalizeTags] Invalid tags input:', tags);
    return [];
  }
  
  return tags.map(tag => {
    if (typeof tag !== 'string') {
      console.warn('[normalizeTags] Non-string tag:', tag);
      return '';
    }
    
    return tag
      .toLowerCase()
      .replace(/["']/g, '') // Remove quotes
      .replace(/\s+dynamics|\s+texture|\s+timbre|\s+quality/g, '') // Remove category suffixes
      .replace(/production style:\s+/, '') // Remove production style prefix
      .trim();
  }).filter(Boolean); // Remove empty tags
} 