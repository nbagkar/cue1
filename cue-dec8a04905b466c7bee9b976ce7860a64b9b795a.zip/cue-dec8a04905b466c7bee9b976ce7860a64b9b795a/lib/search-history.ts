import { supabase } from "./supabase"

export async function logSearch(query: string, social?: string) {
  console.log("[SearchHistory] Starting to log search:", { query })
  const { data: { session } } = await supabase.auth.getSession()
  
  if (!session) {
    console.log("[SearchHistory] No session found, skipping search logging")
    return
  }

  console.log("[SearchHistory] Found session for user:", session.user.id)

  try {
    const { data, error } = await supabase
      .from("search_history")
      .insert([
        {
          user_id: session.user.id,
          query,
        },
      ])
      .select()

    if (error) {
      console.error("[SearchHistory] Error logging search:", error)
    } else {
      console.log("[SearchHistory] Successfully logged search:", data)
    }
  } catch (error) {
    console.error("[SearchHistory] Error in logSearch:", error)
  }
}

export async function getSearchHistory() {
  console.log("Fetching search history")
  const { data: { session } } = await supabase.auth.getSession()
  
  if (!session) {
    console.log("No session found, returning empty search history")
    return []
  }

  console.log("Fetching history for user:", session.user.id)

  try {
    const { data, error } = await supabase
      .from("search_history")
      .select("*")
      .eq("user_id", session.user.id)
      .order("created_at", { ascending: false })
      .limit(20)

    if (error) {
      console.error("Error fetching search history:", error)
      return []
    }

    console.log("Successfully fetched search history:", data)
    return data.map(item => ({
      ...item,
      timestamp: item.created_at // Map created_at to timestamp for compatibility
    }))
  } catch (error) {
    console.error("Error in getSearchHistory:", error)
    return []
  }
}

export async function getFirstSearchPerSocial() {
  const { data: { session } } = await supabase.auth.getSession()
  if (!session) return []

  const { data, error } = await supabase
    .from("search_history")
    .select("query, social, timestamp")
    .eq("user_id", session.user.id)
    .not("social", "is", null)
    .order("timestamp", { ascending: true })
    .limit(10)

  if (error) {
    console.error("Error fetching first searches per social:", error)
    return []
  }

  // Get the first search for each social
  const firstSearches = data.reduce((acc: any[], curr) => {
    if (!acc.find(item => item.social === curr.social)) {
      acc.push(curr)
    }
    return acc
  }, [])

  return firstSearches
}

export async function clearSearchHistory() {
  const { data: { session } } = await supabase.auth.getSession()
  if (!session) return

  try {
    const { error } = await supabase
      .from("search_history")
      .delete()
      .eq("user_id", session.user.id)

    if (error) {
      console.error("Error clearing search history:", error)
    }
  } catch (error) {
    console.error("Error in clearSearchHistory:", error)
  }
} 