import { createClient } from "@supabase/supabase-js"
import { getSemanticSearchQuery } from "./openai"
import type { Database } from "../types/supabase" // Assuming types are generated here

// Hardcoded Supabase credentials
const supabaseUrl = "https://rnmmonnvfrqhfcunpyvt.supabase.co"
const supabaseAnonKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJubW1vbm52ZnJxaGZjdW5weXZ0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDQ1Njc3ODUsImV4cCI6MjA2MDE0Mzc4NX0.YB18Oogxf6z3YUzUZ77ORHdHRVm85Ots-pY8Ltz2Q5Q"

// Define types based on generated Supabase types
type DbSound = Database["public"]["Tables"]["sounds"]["Row"] & {
  description?: string | null;
}

export type Sound = {
  id: string
  name: string
  bpm: number | null
  key: string | null
  duration: number | null
  audioUrl: string | null
  waveform: number[]
  tags: string[]
  description?: string | null
}

export type UserProfile = Database["public"]["Tables"]["profiles"]["Row"]

// Explicitly define Chat type based on expected schema
export type Chat = {
  id: string
  title: string
  user_id: string
  created_at: string
  updated_at: string
}

interface RankedSound {
  sound: DbSound;
  matchScore: number;
}

// Create a singleton supabase client for interacting with your database
const createSupabaseClient = () => {
  if (typeof window === 'undefined') {
    // Server-side: Create a new instance each time
    return createClient<Database>(supabaseUrl, supabaseAnonKey)
  }
  
  // Client-side: Use singleton pattern
  if (!(globalThis as any).supabase) {
    (globalThis as any).supabase = createClient<Database>(supabaseUrl, supabaseAnonKey)
  }
  return (globalThis as any).supabase
}

export const supabase = createSupabaseClient()

// Constants for storage
const STORAGE_BUCKET = 'audio'
const SUPABASE_URL = "https://rnmmonnvfrqhfcunpyvt.supabase.co"
const STORAGE_PUBLIC_URL = `${SUPABASE_URL}/storage/v1/object/public/${STORAGE_BUCKET}`

// Function to get a public URL for a file in storage
async function getStorageUrl(path: string): Promise<string | null> {
  if (!path) {
    console.error("[Storage] getStorageUrl called with empty path.");
    return null;
  }

  try {
    console.log("[Storage] Original path received:", path);

    // If it's already a full URL, return it
    if (path.startsWith('http')) {
      return path;
    }

    // Clean the path: remove leading/trailing slashes and 'audio/' prefix if present
    const cleanPath = path
      .replace(/^\/+/, '') // Remove leading slashes
      .replace(/\/+$/, '') // Remove trailing slashes
      .replace(/^audio\/+/, ''); // Remove 'audio/' prefix if present

    console.log("[Storage] Cleaned path:", cleanPath);

    if (!cleanPath) {
      console.error("[Storage] Path became empty after cleaning:", path);
      return null;
    }

    // Construct the full public URL
    const publicUrl = `${STORAGE_PUBLIC_URL}/${cleanPath}`;
    console.log("[Storage] Generated public URL:", publicUrl);
    return publicUrl;

  } catch (error) {
    console.error(`[Storage] Exception getting storage URL for path '${path}':`, error);
    return null;
  }
}

// Function to fetch sounds from your database
export async function fetchSounds(searchQuery?: string): Promise<DbSound[]> {
  let query = supabase.from("sounds").select("*")

  if (searchQuery) {
    query = query.or(`name.ilike.%${searchQuery}%,sounds.tags:textSearch.${searchQuery}`) // Assuming 'tags' column might still exist temporarily or you search name
    // OR if tags column is gone: query = query.ilike('name', `%${searchQuery}%`) 
  }

  const { data, error } = await query.order("name")

  if (error) {
    console.error("Error fetching sounds:", error)
    return []
  }
  return data as DbSound[] // Ensure return type matches
}

// Function to fetch sounds with semantic search
export async function fetchSoundsWithSemanticSearch(
  userId: string | null,
  query?: string,
  tags: string[] = []
): Promise<Sound[]> {
  // Add very visible console logs
  console.log('\n\n🔍 ====== START SEMANTIC SEARCH FUNCTION ====== 🔍\n');
  console.log('🔍 Search Parameters:', {
    userId,
    query,
    tags
  });

  // Stop words to filter out
  const stopWords = new Set([
    "the", "is", "at", "which", "on", "for", "a", "an", "and", "that", "this", "with", "of", "to", "in", "it", "as", "by", "from", "was", "are", "be", "or", "but", "if", "then", "so", "such", "has", "have", "had", "will", "would", "can", "could", "should", "do", "does", "did", "not", "no", "yes", "you", "i", "we", "they", "he", "she", "him", "her", "them", "us", "our", "your", "their", "my", "mine", "yours", "theirs", "looking", "feels", "good", "intro"]);

  // Combine query and tags into a single array of search terms
  const allSearchTerms: string[] = [];
  
  // Add the main query if it exists
  if (query) {
    // Split the query into individual words, remove punctuation, and filter out stop words
    const words = query
      .toLowerCase()
      .replace(/[^a-z0-9 ]/g, "")
      .split(/\s+/)
      .filter(word => word.length > 1 && !stopWords.has(word));
    allSearchTerms.push(...words);
    console.log('🔍 Split and filtered query into terms:', words);
  }
  
  // Add any tag values
  const allTags = [...tags];
  allTags.forEach(tag => {
    if (!tag || typeof tag !== 'string') return;
    const [category, value] = tag.split(':');
    if (value) {
      allSearchTerms.push(value.toLowerCase());
      console.log('🔍 Added tag value:', value.toLowerCase());
    } else {
      allSearchTerms.push(tag.toLowerCase());
      console.log('🔍 Added simple tag:', tag.toLowerCase());
    }
  });

  // Remove duplicates
  const uniqueSearchTerms = Array.from(new Set(allSearchTerms));
  console.log('🔍 All unique search terms:', uniqueSearchTerms);

  try {
    console.log('🔍 Building search query');
    
    // Base query that gets sounds
    let soundsQuery = supabase.from('sounds').select('*');
    
    // We'll collect all the search conditions
    const queryConditions: string[] = [];
    
    // Search by text query in name and text tags column (if it exists)
    if (uniqueSearchTerms.length > 0) {
      console.log('🔍 Adding search conditions for terms:', uniqueSearchTerms);
      
      // Search in name with partial matches
      uniqueSearchTerms.forEach(term => {
        queryConditions.push(`name.ilike.%${term}%`);
        console.log('🔍 Added name condition for:', term);
      });
      
      // Search in description if it exists
      uniqueSearchTerms.forEach(term => {
        queryConditions.push(`description.ilike.%${term}%`);
        console.log('🔍 Added description condition for:', term);
      });
      
      // Search in key column
      uniqueSearchTerms.forEach(term => {
        queryConditions.push(`key.ilike.%${term}%`);
        console.log('🔍 Added key condition for:', term);
      });
      
      // Search in tags column
      uniqueSearchTerms.forEach(term => {
        queryConditions.push(`tags.ilike.%${term}%`);
        console.log('🔍 Added tags condition for:', term);
      });
    }
    
    // Apply any direct query conditions
    if (queryConditions.length > 0) {
      soundsQuery = soundsQuery.or(queryConditions.join(','));
      console.log('🔍 Applied OR conditions:', queryConditions);
    }
    
    // Run the main query to get candidate sounds
    console.log('🔍 Running initial query with conditions:', queryConditions);
    const { data: initialSounds, error: initialError } = await soundsQuery
      .limit(100); // Increase limit to get more potential matches
    
    if (initialError) {
      console.error('🔍 Error in initial query:', initialError);
      return [];
    }
    
    console.log('🔍 Found initial sounds:', initialSounds?.length || 0);
    
    // If we have no search terms or we didn't find any sounds, return what we have
    if (uniqueSearchTerms.length === 0 || !initialSounds || initialSounds.length === 0) {
      console.log('🔍 Using initial query results:', initialSounds?.length || 0);
      // Map database sounds to app sounds
      const mappedSounds = await Promise.all(
        (initialSounds || []).map(async (dbSound: DbSound) => {
          return mapDbSoundToAppSound(dbSound);
        })
      );
      return mappedSounds;
    }
    
    // If we have search terms, now we need to check which sounds match those terms
    console.log('🔍 Checking which sounds match search terms');
    
    // Get all sound_tags for these sounds
    const soundIds = initialSounds.map((s: DbSound) => s.id);
    
    console.log('🔍 Fetching tags for sounds:', soundIds);
    
    // First try to get tags via the sound_tags relation table
    const { data: soundTagRelations, error: relationsError } = await supabase
      .from('sound_tags')
      .select(`
        sound_id,
        Tag:tag_id (id, name)
      `)
      .in('sound_id', soundIds);
      
    if (relationsError) {
      console.error('🔍 Error fetching sound tag relations:', relationsError);
    } else {
      console.log('🔍 Found sound tag relations:', soundTagRelations?.length || 0);
    }
    
    // Create a map of sound ID to its tags
    const soundTagsMap: Record<string, string[]> = {};
    
    // Process the sound-tag relations
    if (soundTagRelations && soundTagRelations.length > 0) {
      soundTagRelations.forEach((relation: any) => {
        if (!relation.sound_id || !relation.Tag || !relation.Tag.name) {
          console.log('🔍 Skipping invalid relation:', relation);
          return;
        }
        if (!soundTagsMap[relation.sound_id]) {
          soundTagsMap[relation.sound_id] = [];
        }
        soundTagsMap[relation.sound_id].push(relation.Tag.name.toLowerCase());
        console.log('🔍 Added tag to sound:', {
          soundId: relation.sound_id,
          tag: relation.Tag.name.toLowerCase()
        });
      });
    }
    
    console.log('🔍 Final sound tags map:', soundTagsMap);
    
    // Now filter and rank sounds based on how well they match our search terms
    const rankedSounds = initialSounds.map((sound: DbSound) => {
      // Get tags for this sound
      const soundTags = soundTagsMap[sound.id] || [];
      // Also check the text tags column if it exists
      if (sound.tags && typeof sound.tags === 'string') {
        // Remove curly braces and quotes, then split by comma
        const cleanTags = sound.tags.replace(/[{}\"]/g, '');
        const textTags = cleanTags.split(',').map(t => t.trim().toLowerCase());
        soundTags.push(...textTags);
      }
      // Calculate match score
      let matchScore = 0;
      const matchDetails: string[] = [];
      // Prioritize tag matches
      soundTags.forEach(tag => {
        uniqueSearchTerms.forEach(term => {
          if (tag === term) {
            matchScore += 3; // Exact tag match
            matchDetails.push(`Tag exact match for "${term}": +3`);
          } else if (tag.includes(term)) {
            matchScore += 1.5; // Partial tag match
            matchDetails.push(`Tag partial match for "${term}": +1.5`);
          }
        });
      });
      // Check name matches
      const soundName = sound.name.toLowerCase();
      uniqueSearchTerms.forEach(term => {
        if (soundName.includes(term)) {
          matchScore += 1;
          matchDetails.push(`Name match for "${term}": +1`);
        }
      });
      // Check description matches if it exists
      if (sound.description) {
        const description = sound.description.toLowerCase();
        uniqueSearchTerms.forEach(term => {
          if (description.includes(term)) {
            matchScore += 0.5;
            matchDetails.push(`Description match for "${term}": +0.5`);
          }
        });
      }
      console.log('🔍 Sound score:', {
        name: sound.name,
        score: matchScore,
        details: matchDetails
      });
      return { sound, matchScore } as RankedSound;
    });
    // Sort by match score and get the sounds
    const finalSounds = rankedSounds
      .sort((a: RankedSound, b: RankedSound) => b.matchScore - a.matchScore)
      .slice(0, 10) // Limit to top 10 matches
      .map((item: RankedSound) => item.sound);
    console.log('🔍 Final results:', finalSounds.map((s: DbSound) => ({
      name: s.name,
      score: rankedSounds.find((r: RankedSound) => r.sound.id === s.id)?.matchScore
    })));
    console.log('\n🔍 ====== END SEMANTIC SEARCH FUNCTION ====== 🔍\n');
    // Map database sounds to app sounds
    const mappedSounds = await Promise.all(
      finalSounds.map(async (dbSound: DbSound) => {
        return mapDbSoundToAppSound(dbSound);
      })
    );
    return mappedSounds;
  } catch (error) {
    console.error('\n🔍 Error in semantic search:', error, '\n');
    return [];
  }
}

// Function to fetch random sounds as a fallback
async function fetchRandomSounds(userId: string | null, limit: number = 10): Promise<Sound[]> {
  console.log(`[fetchRandomSounds] Fetching ${limit} random sounds`);
  
  try {
    const { data: dbSounds, error } = await supabase
      .from('sounds')
      .select('*')
      .order('id')
      .limit(limit);
      
    if (error) {
      console.error('[fetchRandomSounds] Error fetching random sounds:', error);
      return [];
    }
    
    if (!dbSounds || dbSounds.length === 0) {
      console.warn('[fetchRandomSounds] No random sounds found');
      return [];
    }
    
    console.log(`[fetchRandomSounds] Found ${dbSounds.length} random sounds`);
    
    // Map database sounds to app sounds
    return await Promise.all(dbSounds.map(mapDbSoundToAppSound));
  } catch (error) {
    console.error('[fetchRandomSounds] Exception:', error);
    return [];
  }
}

// Function to map database sounds to your application's Sound type
export async function mapDbSoundToAppSound(dbSound: DbSound): Promise<Sound> {
  const waveform = Array.from({ length: 50 }, () => Math.random() * 0.8 + 0.2)

  let audioUrl = null
  if (dbSound.url) {
    try {
      console.log(`[mapDbSoundToAppSound] Processing URL for sound ${dbSound.id}:`, dbSound.url);
      audioUrl = await getStorageUrl(dbSound.url);
      console.log(`[mapDbSoundToAppSound] Generated audio URL:`, audioUrl);
    } catch (error) {
      console.error(`[mapDbSoundToAppSound] Error processing URL for sound ${dbSound.id}:`, error);
    }
  }

  // Fetch tags from the new sound_tags join table
  let tagsArray: string[] = []
  try {
    console.log(`[mapDbSoundToAppSound] Fetching tags for sound ${dbSound.id}`);
    
    const { data: tagsData, error: tagsError } = await supabase
      .from('sound_tags')
      .select(`
        tag_id,
        Tag:tag_id ( id, name )
      `)
      .eq('sound_id', dbSound.id);

    if (tagsError) {
      console.error(`[mapDbSoundToAppSound] Error fetching tags for sound ${dbSound.id}:`, tagsError);
    } else if (tagsData && Array.isArray(tagsData)) {
      console.log(`[mapDbSoundToAppSound] Found ${tagsData.length} tag associations for sound ${dbSound.id}`);
      
      // Extract tag names, making sure to access the correct nested property
      tagsArray = tagsData
        .map((item: any) => item.Tag?.name)
        .filter(Boolean) as string[];
        
      console.log(`[mapDbSoundToAppSound] Extracted ${tagsArray.length} tag names:`, tagsArray);
    } else {
      console.log(`[mapDbSoundToAppSound] No tags found for sound ${dbSound.id}`);
    }
  } catch (error) {
    console.error(`[mapDbSoundToAppSound] Exception fetching tags for sound ${dbSound.id}:`, error);
  }

  return {
    id: dbSound.id,
    name: dbSound.name || "Unnamed Sound",
    bpm: dbSound.bpm,
    key: dbSound.key,
    duration: dbSound.len,
    audioUrl: audioUrl,
    waveform,
    tags: tagsArray,
    description: dbSound.description,
  }
}

// Function to check if an audio URL is valid/accessible
export async function checkAudioUrl(url: string): Promise<boolean> {
  if (!url) return false

  try {
    const response = await fetch(url, { method: "HEAD" })
    return response.ok
  } catch (error) {
    console.error("Error checking audio URL:", error)
    return false
  }
}

// Function to get user profile
export async function getUserProfile(userId: string): Promise<UserProfile | null> {
  const { data, error } = await supabase.from("profiles").select("*").eq("id", userId).single()

  if (error) {
    console.error("Error fetching user profile:", error)
    return null
  }

  return data as UserProfile
}

// Function to save a sound to user's library
export async function saveSound(userId: string, soundId: string): Promise<boolean> {
  const { error } = await supabase.from("user_sounds").insert([{ profile_id: userId, sound_id: soundId }])

  if (error) {
    console.error("Error saving sound:", error)
    return false
  }

  return true
}

// Function to remove a sound from user's library
export async function removeSound(userId: string, soundId: string): Promise<boolean> {
  const { error } = await supabase.from("user_sounds").delete().eq("profile_id", userId).eq("sound_id", soundId)

  if (error) {
    console.error("Error removing sound:", error)
    return false
  }

  return true
}

// Function to get user's saved sounds
export async function getUserSavedSounds(userId: string): Promise<DbSound[]> {
  // First get the sound IDs saved by this user
  const { data: savedData, error: savedError } = await supabase
    .from("user_sounds")
    .select("sound_id")
    .eq("profile_id", userId)

  if (savedError) {
    console.error("Error fetching user saved sounds:", savedError)
    return []
  }

  if (!savedData || savedData.length === 0) {
    console.log(`No saved sounds found for user ${userId}`)
    return []
  }

  // Extract the sound IDs
  const soundIds = savedData.map((item: { sound_id: string }) => item.sound_id)
  console.log(`Found ${soundIds.length} saved sound IDs for user ${userId}`)

  // Fetch the actual sound data
  const { data: sounds, error: soundsError } = await supabase.from("sounds").select("*").in("id", soundIds)

  if (soundsError) {
    console.error("Error fetching saved sound details:", soundsError)
    return []
  }

  return sounds || []
}

// Function to create a new chat
export async function createChat(title: string, userId: string): Promise<Chat | null> {
  const { data, error } = await supabase
    .from('chats')
    .insert([{ title, user_id: userId }])
    .select()
    .single()

  if (error) {
    console.error('Error creating chat:', error)
    return null
  }

  return data
}

// Function to get user's chats
export async function getUserChats(userId: string): Promise<Chat[]> {
  const { data, error } = await supabase
    .from('chats')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false })

  if (error) {
    console.error('Error fetching user chats:', error)
    return []
  }

  return data
}

// Function to update a chat
export async function updateChat(chatId: string, title: string): Promise<boolean> {
  const { error } = await supabase
    .from('chats')
    .update({ title })
    .eq('id', chatId)

  if (error) {
    console.error('Error updating chat:', error)
    return false
  }

  return true
}

// Function to delete a chat
export async function deleteChat(chatId: string): Promise<boolean> {
  const { error } = await supabase
    .from('chats')
    .delete()
    .eq('id', chatId)

  if (error) {
    console.error('Error deleting chat:', error)
    return false
  }

  return true
}

// Function to check if a user has saved a sound
export async function isUserSavedSound(userId: string, soundId: string): Promise<boolean> {
  const { data, error } = await supabase
    .from("user_sounds")
    .select("id")
    .eq("profile_id", userId)
    .eq("sound_id", soundId)
    .single()

  if (error) {
    // If the error is 'not found', it means the user hasn't saved this sound
    if (error.code === "PGRST116") {
      return false
    }
    console.error("Error checking if user saved sound:", error)
    return false
  }

  return !!data
}

// Function to clear user's library
export async function clearUserLibrary(userId: string): Promise<boolean> {
  const { error } = await supabase.from("user_sounds").delete().eq("profile_id", userId)

  if (error) {
    console.error("Error clearing user library:", error)
    return false
  }

  return true
}

