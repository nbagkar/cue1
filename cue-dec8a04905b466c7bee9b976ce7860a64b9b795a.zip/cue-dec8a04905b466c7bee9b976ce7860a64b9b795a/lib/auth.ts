import { supabase } from "./supabase"

export async function signIn(email: string, password: string) {
  try {
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    })

    if (error) {
      return { success: false, error: error.message }
    }

    return { success: true }
  } catch (error) {
    console.error("Sign in error:", error)
    return { success: false, error: "An unexpected error occurred" }
  }
}

export async function signUp(email: string, password: string, name: string) {
  try {
    // First create the user
    const { data: authData, error: authError } = await supabase.auth.signUp({
      email,
      password,
    })

    if (authError) {
      console.error("Auth error:", authError)
      return { success: false, error: authError.message }
    }

    if (!authData.user) {
      return { success: false, error: "User creation failed" }
    }

    // Create profile in a separate transaction
    const { error: profileError } = await supabase
      .from("profiles")
      .insert({
        id: authData.user.id,
        name: name,
        email: email,
      })
      .select()
      .single()

    if (profileError) {
      console.error("Profile creation error:", profileError)
      // Don't sign out - let them try again if profile creation fails
      return {
        success: false,
        error: "Failed to create user profile. Please try again."
      }
    }

    return { success: true }
  } catch (error) {
    console.error("Sign up exception:", error)
    return { success: false, error: "An unexpected error occurred during sign up" }
  }
}

export async function signOut() {
  try {
    const { error } = await supabase.auth.signOut()
    if (error) {
      console.error('Sign out error:', error)
      throw error
    }
    // Clear any local storage items that might be related to auth
    localStorage.clear()
    // Force a hard reload to clear any cached state
    window.location.href = '/'
  } catch (error) {
    console.error('Error during sign out:', error)
    throw error
  }
}

export async function signInWithGoogle() {
  try {
    const { data, error } = await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: {
        redirectTo: `${window.location.origin}/auth/callback`,
        queryParams: {
          access_type: 'offline',
          prompt: 'consent',
        },
        skipBrowserRedirect: true // Let us handle the redirect manually
      }
    })

    if (error) {
      console.error("Google sign in error:", error)
      return { success: false, error: error.message }
    }

    // Manually redirect to the authorization URL
    if (data?.url) {
      window.location.href = data.url
    }

    return { success: true }
  } catch (error) {
    console.error("Google sign in error:", error)
    return { success: false, error: "An unexpected error occurred" }
  }
}

export async function handleAuthStateChange(
  callback: (session: any) => void
) {
  return supabase.auth.onAuthStateChange((event, session) => {
    if (event === 'SIGNED_IN') {
      // If user doesn't exist in profiles, create profile
      if (session?.user) {
        createProfileIfNotExists(session.user)
      }
    }
    callback(session)
  })
}

async function createProfileIfNotExists(user: any) {
  try {
    // Check if profile exists
    const { data: profile, error: fetchError } = await supabase
      .from('profiles')
      .select()
      .eq('id', user.id)
      .single()

    if (fetchError && fetchError.code !== 'PGRST116') { // PGRST116 means no rows returned
      console.error("Error fetching profile:", fetchError)
      return
    }

    // If profile doesn't exist, create it
    if (!profile) {
      console.log('Creating new profile for user:', user.id)
      const { error: insertError } = await supabase
        .from('profiles')
        .insert({
          id: user.id,
          email: user.email,
          name: user.user_metadata?.full_name || user.email?.split('@')[0],
        })
        .select()
        .single()

      if (insertError) {
        console.error("Error creating profile:", insertError)
        // If profile creation fails, sign out the user to prevent partial state
        await supabase.auth.signOut()
        throw new Error("Failed to create profile. Please try signing in again.")
      }
    }
  } catch (error) {
    console.error("Error in createProfileIfNotExists:", error)
    throw error
  }
} 