-- Create profiles table
CREATE TABLE IF NOT EXISTS profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  name TEXT,
  email TEXT UNIQUE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create sounds table (if it doesn't exist already)
CREATE TABLE IF NOT EXISTS sounds (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  url TEXT,
  tags TEXT,
  key TEXT,
  bpm INTEGER,
  len INTEGER,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create user_sounds table for saved sounds
CREATE TABLE IF NOT EXISTS user_sounds (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  sound_id UUID REFERENCES sounds(id) ON DELETE CASCADE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(user_id, sound_id)
);

-- Create saved_searches table
CREATE TABLE IF NOT EXISTS saved_searches (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  query TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create RLS policies

-- Profiles: Users can read all profiles but only update their own
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Public profiles are viewable by everyone" 
  ON profiles FOR SELECT USING (true);

CREATE POLICY "Users can update their own profile" 
  ON profiles FOR UPDATE USING (auth.uid() = id);

-- Allow users to insert their own profile
CREATE POLICY "Users can insert their own profile" 
  ON profiles FOR INSERT WITH CHECK (auth.uid() = id);

-- Sounds: Anyone can read sounds
ALTER TABLE sounds ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Sounds are viewable by everyone" 
  ON sounds FOR SELECT USING (true);

-- User_sounds: Users can only see and manage their own saved sounds
ALTER TABLE user_sounds ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own saved sounds" 
  ON user_sounds FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own saved sounds" 
  ON user_sounds FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own saved sounds" 
  ON user_sounds FOR DELETE USING (auth.uid() = user_id);

-- Saved_searches: Users can only see and manage their own saved searches
ALTER TABLE saved_searches ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own saved searches" 
  ON saved_searches FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own saved searches" 
  ON saved_searches FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own saved searches" 
  ON saved_searches FOR DELETE USING (auth.uid() = user_id);
