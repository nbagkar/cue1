-- Create search_history table
CREATE TABLE IF NOT EXISTS public.search_history (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  query TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE public.search_history ENABLE ROW LEVEL SECURITY;

-- Drop existing policies to avoid conflicts
DROP POLICY IF EXISTS "User can view own searches" ON public.search_history;
DROP POLICY IF EXISTS "User can insert own search" ON public.search_history;
DROP POLICY IF EXISTS "User can delete own searches" ON public.search_history;

-- Create policies
CREATE POLICY "User can view own searches"
  ON public.search_history FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "User can insert own search"
  ON public.search_history FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "User can delete own searches"
  ON public.search_history FOR DELETE
  USING (auth.uid() = user_id);

-- Grant necessary permissions
GRANT ALL ON public.search_history TO authenticated;
GRANT ALL ON public.search_history TO service_role; 