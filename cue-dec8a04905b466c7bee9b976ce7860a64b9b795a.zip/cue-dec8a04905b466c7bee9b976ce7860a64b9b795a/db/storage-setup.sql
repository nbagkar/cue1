-- Enable storage
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Create storage bucket for sounds if it doesn't exist
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'sounds',
  'sounds',
  false,
  52428800, -- 50MB in bytes
  ARRAY['audio/mpeg', 'audio/wav', 'audio/mp3', 'audio/x-wav']
)
ON CONFLICT (id) DO NOTHING;

-- Enable Row Level Security (RLS) on the bucket
ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;

-- Create policies for the sounds bucket
DROP POLICY IF EXISTS "Users can upload sounds" ON storage.objects;
DROP POLICY IF EXISTS "Users can update their own sounds" ON storage.objects;
DROP POLICY IF EXISTS "Users can read their own sounds" ON storage.objects;
DROP POLICY IF EXISTS "Users can delete their own sounds" ON storage.objects;

-- Allow authenticated users to upload sounds
CREATE POLICY "Users can upload sounds"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'sounds' AND
  (storage.foldername(name))[1] = auth.uid()::text
);

-- Allow users to update their own sounds
CREATE POLICY "Users can update their own sounds"
ON storage.objects FOR UPDATE
TO authenticated
USING (
  bucket_id = 'sounds' AND
  (storage.foldername(name))[1] = auth.uid()::text
);

-- Allow users to read their own sounds
CREATE POLICY "Users can read their own sounds"
ON storage.objects FOR SELECT
TO authenticated
USING (
  bucket_id = 'sounds' AND
  (storage.foldername(name))[1] = auth.uid()::text
);

-- Allow users to delete their own sounds
CREATE POLICY "Users can delete their own sounds"
ON storage.objects FOR DELETE
TO authenticated
USING (
  bucket_id = 'sounds' AND
  (storage.foldername(name))[1] = auth.uid()::text
); 