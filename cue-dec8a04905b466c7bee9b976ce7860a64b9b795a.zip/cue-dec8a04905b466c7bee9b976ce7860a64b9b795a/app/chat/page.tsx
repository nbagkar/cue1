import { ChatInterface } from "@/components/chat-interface"

export default function ChatPage() {
  return <ChatInterface />
}
