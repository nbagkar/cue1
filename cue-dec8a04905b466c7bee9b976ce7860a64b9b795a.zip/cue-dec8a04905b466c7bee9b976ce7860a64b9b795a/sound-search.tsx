"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { Search, Mic, Music, AudioWaveformIcon as Waveform, Volume2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { useTheme } from "@/context/theme-context"
import { useAuth } from "@/context/auth-context"
import { cn } from "@/lib/utils"
import { SoundCard } from "@/components/sound-card"
import type { Sound } from "@/types/sound"
import { fetchSounds, mapDbSoundToAppSound } from "@/lib/supabase"
import { logSearch } from "@/lib/search-history"
import { SavedSearches } from "@/components/saved-searches"

interface SearchSection {
  id: string
  query: string
  results: Sound[]
}

interface SoundCategory {
  name: string;
  keyword: string; // Added keyword for API
  icon: React.ReactNode;
}

export default function SoundSearch() {
  const [searchQuery, setSearchQuery] = useState<string>("")
  const [activeFilters, setActiveFilters] = useState<string[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [searchSections, setSearchSections] = useState<SearchSection[]>([])
  const [searchResults, setSearchResults] = useState<Sound[]>([])
  const [errorMessage, setErrorMessage] = useState<string>("")
  const [isSearching, setIsSearching] = useState(false)
  const [followUpQuery, setFollowUpQuery] = useState("")
  const [editingSound, setEditingSound] = useState<Sound | null>(null)
  const { theme } = useTheme()
  const { user } = useAuth()
  const resultsContainerRef = useRef<HTMLDivElement>(null)
  const searchInputRef = useRef<HTMLInputElement>(null)
  const isInitialMount = useRef(true); // Ref to track initial mount

  // --- New: Listen for rerunSearch event from SavedSearches ---
  useEffect(() => {
    const handleRerunSearch = (event: CustomEvent) => {
      const { query } = event.detail
      if (query) {
        console.log(`[SoundSearch] Received rerunSearch event for query: ${query}`)
        setSearchQuery(query)
        // Optionally clear filters when running a saved search
        // setActiveFilters([]) 
        // Trigger the search immediately after setting the query
        // Need to use a small timeout or useEffect based on searchQuery change
        // to ensure state update is processed before search runs.
      }
    }

    window.addEventListener('rerunSearch' as any, handleRerunSearch)

    return () => {
      window.removeEventListener('rerunSearch' as any, handleRerunSearch)
    }
  }, []) // Empty dependency array means this runs once on mount

  // --- New: Effect to trigger search when searchQuery changes programmatically ---
  useEffect(() => {
    // Don't run on initial mount or if loading
    if (isInitialMount.current || isLoading) {
      return
    }
    // Check if the searchQuery state actually changed
    // (avoids infinite loops if handleSearch itself modifies searchQuery indirectly)
    console.log("[SoundSearch] searchQuery changed, triggering handleSearch...");
    handleSearch();
    
  }, [searchQuery]); // Run when searchQuery changes

  const soundCategories: SoundCategory[] = [
    { name: "Ambient", keyword: "mood:ambient", icon: <Waveform className="h-4 w-4" /> },
    { name: "Music", keyword: "instrument/source:music", icon: <Music className="h-4 w-4" /> },
    { name: "Voice", keyword: "instrument/source:voice", icon: <Mic className="h-4 w-4" /> },
    { name: "Effects", keyword: "genre:effects", icon: <Volume2 className="h-4 w-4" /> },
    // Add more representative filters if needed, mapping display name to API keyword
    { name: "Vintage", keyword: "style:vintage", icon: <span>V</span> }, // Example
    { name: "Warm", keyword: "mood:warm", icon: <span>W</span> }, // Example
    { name: "Keys", keyword: "instrument/source:keys", icon: <span>K</span> }, // Example
  ]

  const isDark = theme === "dark"

  // Function to toggle filters
  const handleFilterToggle = (keyword: string) => {
    setActiveFilters((prevFilters) => {
      const newFilters = prevFilters.includes(keyword)
        ? prevFilters.filter((k) => k !== keyword) // Remove filter
        : [...prevFilters, keyword]; // Add filter
      console.log('[SoundSearch] Filters toggled:', newFilters); // Log filter changes
      return newFilters;
    });
    // Note: We will trigger the search via useEffect based on activeFilters change
  }

  // Set a fixed height for the results container based on viewport height
  useEffect(() => {
    if (isSearching && resultsContainerRef.current) {
      // Set the height to viewport height minus the search bar height (approx 80px) and some padding
      resultsContainerRef.current.style.height = `calc(100vh - 100px)`
    }
  }, [isSearching])

  // Scroll to show primarily new results but with a glimpse of previous results
  useEffect(() => {
    if (resultsContainerRef.current && searchSections.length > 1) {
      // Get the height of the results container
      const containerHeight = resultsContainerRef.current.clientHeight

      // Calculate a position that shows primarily new results but with a glimpse of previous ones
      // Scroll to a position that's about 15% from the bottom
      const scrollPosition = resultsContainerRef.current.scrollHeight - containerHeight * 0.85

      // Scroll to the calculated position
      resultsContainerRef.current.scrollTop = scrollPosition
    } else if (resultsContainerRef.current && searchSections.length === 1) {
      // For the first search, show from the top
      resultsContainerRef.current.scrollTop = 0
    }
  }, [searchSections])

  // --- New useEffect to trigger search on filter change ---
  useEffect(() => {
    // Prevent running search on initial mount
    if (isInitialMount.current) {
      isInitialMount.current = false;
      return;
    }

    // Trigger search if filters are changed and not already loading
    if (!isLoading) {
      console.log('[SoundSearch] activeFilters changed, triggering handleSearch...');
      handleSearch();
    }
  }, [activeFilters]); // Dependency array includes activeFilters
  // --- End of new useEffect ---

  const handleSearch = async () => {
    console.log("🔍 ====== START CLIENT SEARCH ====== 🔍");
    console.log("[SoundSearch] Search triggered with query:", searchQuery, "and filters:", activeFilters)
    // Allow search even with empty text query if filters are selected
    if (!searchQuery?.trim() && activeFilters.length === 0) {
      console.log("[SoundSearch] Empty search query and no filters, skipping search")
      return
    }

    setIsLoading(true)

    try {
      const searchPayload = {
        query: searchQuery?.trim() || "", // Send empty string if query is just whitespace
        tags: activeFilters,
      }
      // Don't add filter information to the query display
      const logText = searchQuery?.trim() || (activeFilters.length > 0 ? `Filters: ${activeFilters.join(', ')}` : '');

      // Log the search query and filters
      console.log("[SoundSearch] Logging search to history:", logText)
      await logSearch(logText) // Log search query

      // Call semantic search API with query and keywords
      console.log("🔍 Calling semantic search API with payload:", searchPayload)
      const response = await fetch('/api/semantic-search', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(searchPayload), // Send both query and tags
      })

      console.log("🔍 API Response status:", response.status);
      console.log("🔍 API Response headers:", Object.fromEntries(response.headers.entries()));

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({ error: 'Unknown error' }));
        console.error(`🔍 API request failed with status ${response.status}:`, errorData);
        setErrorMessage(`Search failed: ${errorData.error || 'Unknown error'}`);
        setIsLoading(false);
        return;
      }

      try {
        const { sounds, logs } = await response.json();
        console.log(`🔍 API returned ${sounds?.length || 0} sounds:`, sounds);
        
        // Log the API logs
        if (logs && Array.isArray(logs)) {
          console.log('\n🔍 API Logs:');
          logs.forEach(log => console.log(log));
        }
        
        if (!sounds || sounds.length === 0) {
          console.warn('🔍 No sounds returned from API');
          setSearchResults([]);
          setErrorMessage('No sounds found matching your search.');
        } else {
          setSearchResults(sounds);
          setErrorMessage('');
        }
        
        const newSection: SearchSection = {
          id: `search-${Date.now()}`,
          query: logText, // Use the logged text representation for display
          results: sounds,
        }

        // Update search sections
        setSearchSections(prev => [newSection, ...prev].slice(0, 10))
        setIsSearching(true) // Ensure we're in search mode when we get results
      } catch (error) {
        console.error('🔍 Error processing API response:', error);
        setSearchResults([]);
        setErrorMessage('Error processing search results.');
      } finally {
        setIsLoading(false);
      }
    } catch (error) {
      console.error('🔍 Error searching sounds:', error)
    }
    console.log("🔍 ====== END CLIENT SEARCH ====== 🔍");
  }

  const handleFollowUpSearch = async () => {
    if (followUpQuery.trim() && searchSections.length > 0) {
      setIsLoading(true)

      try {
        // Log the follow-up search query
        console.log("[SoundSearch] Logging follow-up search to history:", followUpQuery)
        await logSearch(followUpQuery)
        console.log("[SoundSearch] Successfully logged follow-up search to history")

        // Call semantic search API
        const response = await fetch('/api/semantic-search', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-user-id': user?.id || '',
          },
          body: JSON.stringify({ query: followUpQuery }),
        })

        if (!response.ok) {
          throw new Error('Failed to perform semantic search')
        }

        const { sounds, keywords } = await response.json()

        const newSection: SearchSection = {
          id: `search-${Date.now()}`,
          query: followUpQuery,
          results: sounds,
        }

        // Add new search to the end of the array (will be displayed at the bottom)
        setSearchSections([...searchSections, newSection])
        setFollowUpQuery("")
      } catch (error) {
        console.error("Error searching sounds:", error)
      } finally {
        setIsLoading(false)
      }
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      handleSearch()
    }
  }

  const handleFollowUpKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      handleFollowUpSearch()
    }
  }

  const handleEditMode = (isEditing: boolean, sound: Sound) => {
    setEditingSound(isEditing ? sound : null)
  }

  const insertEditText = (type: "bpm" | "key") => {
    if (!editingSound) return

    // Provide default text or calculation if bpm/key is null
    const prefix =
      type === "bpm"
        ? `Change BPM to ${editingSound.bpm !== null ? editingSound.bpm + 10 : '120'}` // Default to 120 if null
        : `Change Key to ${editingSound.key === "C maj" ? "D maj" : "C maj"}` // Existing logic might be okay if key is never null in edit mode, or add null check
        // Consider adding a null check for key as well if necessary:
        // : `Change Key to ${editingSound.key ? (editingSound.key === "C maj" ? "D maj" : "C maj") : 'C maj'}`

    setFollowUpQuery(prefix)

    // Focus the input
    if (searchInputRef.current) {
      searchInputRef.current.focus()
    }
  }

  const handleHistorySelect = (query: string) => {
    console.log("Selected search from history:", query)
    setSearchQuery(query)
    if (searchInputRef.current) {
      searchInputRef.current.focus()
    }
  }

  return (
    <div className={cn("flex flex-col h-full w-full", isDark ? "bg-[#161616] text-white" : "bg-gray-50 text-gray-900")}>
      {!isSearching ? (
        // Initial search screen
        <div className="w-full max-w-2xl mx-auto flex flex-col items-center justify-center min-h-screen p-4">
          <h1
            className={cn("text-2xl font-medium mb-6 text-center font-serif", isDark ? "text-white" : "text-gray-900")}
          >
            Search for your perfect sound
          </h1>

          <div className="w-full relative mb-6">
            <div
              className={cn(
                "relative rounded-full overflow-hidden",
                isDark ? "bg-[#212121]" : "bg-white border border-gray-200",
              )}
            >
              <Input
                ref={searchInputRef}
                type="text"
                placeholder="A night at a broadway show with smooth jazz"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyDown={handleKeyDown}
                className={cn(
                  "bg-transparent border-0 py-7 px-4 focus-visible:ring-0 focus-visible:ring-offset-0 rounded-full",
                  isDark ? "text-white placeholder:text-gray-400" : "text-gray-900 placeholder:text-gray-500",
                )}
              />
              <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center">
                <Button
                  size="icon"
                  variant="ghost"
                  onClick={handleSearch}
                  disabled={isLoading}
                  className={cn(
                    "h-10 w-10 rounded-full transition-colors duration-200",
                    searchQuery.trim()
                      ? "bg-purple-600 hover:bg-purple-700 text-white"
                      : isDark
                        ? "bg-transparent hover:bg-[#2a2a2a] text-gray-300"
                        : "bg-transparent hover:bg-gray-100 text-gray-500",
                  )}
                >
                  {isLoading ? (
                    <div className="h-5 w-5 border-2 border-t-transparent border-white rounded-full animate-spin" />
                  ) : (
                    <Search className="h-5 w-5" />
                  )}
                </Button>
              </div>
            </div>
          </div>

          <div className="flex flex-wrap justify-center gap-2 mb-6">
            {soundCategories.map((category) => {
              const isActive = activeFilters.includes(category.keyword);
              return (
                <Button
                  key={category.keyword} // Use keyword as key
                  variant="outline"
                  onClick={() => handleFilterToggle(category.keyword)} // Add onClick handler
                  className={cn(
                    "bg-transparent font-normal rounded-full transition-all duration-200",
                    isDark
                      ? "border border-[#333] text-gray-300 hover:border-purple-500"
                      : "border border-gray-300 text-gray-600 hover:border-purple-600",
                    // Active state styling
                    isActive && isDark
                      ? "bg-purple-800/50 border-purple-700 text-white"
                      : isActive && !isDark
                        ? "bg-purple-100 border-purple-400 text-purple-800"
                        : "", // Default state
                  )}
                >
                  {category.icon}
                  <span className="ml-1">{category.name}</span>
                </Button>
              )
            })}
          </div>
        </div>
      ) : (
        // Search results screen with fixed height container and internal scrolling
        <div className="flex flex-col w-full h-screen">
          {/* Fixed height container with internal scrolling */}
          <div
            ref={resultsContainerRef}
            className={cn("w-full overflow-y-auto pb-24", isDark && "dark-scrollbar")}
            style={{ height: "calc(100vh - 100px)" }}
          >
            <div className="w-full max-w-4xl mx-auto py-8 px-4">
              {/* Display search sections in the same order they were added */}
              {searchSections.map((section, index) => (
                <div key={section.id} className="mb-6">
                  <div className="mb-6 text-center">
                    <h2 className={cn("text-lg font-medium", isDark ? "text-gray-400" : "text-gray-500")}>
                      {section.query}
                    </h2>
                  </div>

                  <div className="flex flex-col items-center">
                    {section.results.length > 0 ? (
                      section.results.map((sound) => (
                        <SoundCard key={`${section.id}-${sound.id}`} sound={sound} onEditMode={handleEditMode} />
                      ))
                    ) : (
                      <div className="text-center py-6">
                        <p className={cn("text-sm", isDark ? "text-gray-400" : "text-gray-500")}>
                          {errorMessage || "No results found for this search."}
                        </p>
                      </div>
                    )}
                  </div>

                  {index < searchSections.length - 1 && (
                    <div className={cn("border-t my-8", isDark ? "border-[#212121]" : "border-gray-200")} />
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Fixed search bar at bottom */}
          <div
            className={cn(
              "w-full p-4 pt-5",
              isDark ? "bg-[#161616]" : "bg-gray-50",
              // Add gradient fade effect above the search bar
              "before:content-[''] before:absolute before:left-0 before:right-0 before:top-[-16px] before:h-4",
              isDark
                ? "before:bg-gradient-to-t before:from-[#161616] before:to-transparent"
                : "before:bg-gradient-to-t before:from-gray-50 before:to-transparent",
            )}
          >
            {/* Edit mode bubbles */}
            {editingSound && (
              <div className="flex justify-center gap-2 mb-3">
                <button
                  onClick={() => insertEditText("bpm")}
                  className={cn(
                    "px-3 py-1 rounded-full text-sm transition-colors",
                    isDark
                      ? "bg-[#212121] text-white hover:bg-[#2a2a2a]"
                      : "bg-white text-gray-900 border border-gray-200 hover:bg-gray-100",
                  )}
                >
                  Change BPM
                </button>
                <button
                  onClick={() => insertEditText("key")}
                  className={cn(
                    "px-3 py-1 rounded-full text-sm transition-colors",
                    isDark
                      ? "bg-[#212121] text-white hover:bg-[#2a2a2a]"
                      : "bg-white text-gray-900 border border-gray-200 hover:bg-gray-100",
                  )}
                >
                  Change Key
                </button>
              </div>
            )}

            <div className="w-full max-w-2xl mx-auto">
              <div
                className={cn(
                  "relative rounded-full overflow-hidden",
                  isDark ? "bg-[#212121]" : "bg-white border border-gray-200 shadow-lg",
                )}
              >
                <input
                  ref={searchInputRef}
                  type="text"
                  placeholder="Refine your search..."
                  value={followUpQuery}
                  onChange={(e) => setFollowUpQuery(e.target.value)}
                  onKeyDown={handleFollowUpKeyDown}
                  className={cn(
                    "w-full bg-transparent border-0 py-3 px-4 focus:ring-0 focus:outline-none rounded-full",
                    isDark ? "text-white placeholder:text-gray-400" : "text-gray-900 placeholder:text-gray-500",
                  )}
                  style={{ WebkitAppearance: "none", appearance: "none" }}
                />
                <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center">
                  <Button
                    size="icon"
                    variant="ghost"
                    onClick={handleFollowUpSearch}
                    disabled={isLoading}
                    className={cn(
                      "h-10 w-10 rounded-full transition-colors duration-200",
                      followUpQuery.trim()
                        ? "bg-purple-600 hover:bg-purple-700 text-white"
                        : isDark
                          ? "bg-transparent hover:bg-[#2a2a2a] text-gray-300"
                          : "bg-transparent hover:bg-gray-100 text-gray-500",
                    )}
                  >
                    {isLoading ? (
                      <div className="h-5 w-5 border-2 border-t-transparent border-white rounded-full animate-spin" />
                    ) : (
                      <Search className="h-5 w-5" />
                    )}
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
